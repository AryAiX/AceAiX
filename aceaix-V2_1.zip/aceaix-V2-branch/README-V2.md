# AceAiX — branch `V2`

```
repo    github.com/AryAiX/AceAiX          ← this one, NOT AceAiX_MVP_application
branch  V2
tip     9d861df
base    03d1830   ← current main, already merged in
```

Three commands, from a clone of **that** repository:

```bash
git fetch origin main
git fetch /path/to/V2.bundle V2:V2
git push origin V2
```

Then open a PR into `main`. **Zero conflicts** — current `main` is already
merged into the branch.

The bundle is a delta against `origin/main`, so `git fetch origin main` first is
not optional: it carries commits `3d11643` and `03d1830` as prerequisites, and
both live in `AceAiX` only. `AceAiX_MVP_application` shares no history with this
repository, which is why the same file looked broken there.

Push access was not available where these commits were written; that is the only
reason they arrive as a file.

---

## What is on it

Ten commits. The first five are the rebuild and are described in
`docs/README.md`; the last five are new.

```
3222f79  Rebuild AceAiX as a talent-discovery network
7a0cba5  Add a single-file preview build, and stop shipping 1,500 unused icons
c12b049  Fandom, challenges, and the store assets that were never made
0ca5a77  Fix the preview dropping onto "this page has moved on"
1f6a43d  Give the app a colour, and put the plus back in the middle
ab54df4  Merge origin/main into rebuild/talent-network
5942335  Stop carrying a 61 MB build artefact in the tree
c5b90a1  Meetups, and a translate line under anything somebody wrote
20f396d  Endorsements you can actually give, and three edges that were wrong  ← new
45d76cc  Silence two web console warnings, at the import rather than the call   ← new
9d861df  Check that a write by one person reaches another person                ← new
```

---

## The two new features, and the part to review carefully

### Meetups

"I'm in Marbella Thursday and want a tennis partner" and "I have a pitch
Saturday and need fifteen more to split the cost" are the same request — a sport,
a place, a time, a number of people, a level. One table; `spots_total` is the only
thing separating them. Cards lead with what is left ("4 of 10 · 6 spots left"),
the host approves, and asking does not take a spot — accepting does.

**This is eighteen-plus, and the database is what says so.**
`docs/12-youth-safety.md` rule 5 is the strongest guarantee in the product: a
minor's precise location is never held at all, and no coordinate column exists
anywhere. A meetup is the exact inverse — a named venue, an exact time, published
to strangers, with a promise the poster will be standing there.

So there are three independent gates, all in the database:

1. `private.may_meet()`, called first by every writing function
2. the same predicate inside the RLS read policies, so a minor's client gets an
   empty set from the server rather than a hidden tab in the app
3. a `BEFORE INSERT` trigger on `meetup_participants`, which refuses regardless of
   which path created the row — service-role code included

**If you change one thing in this branch, do not make it one of those.** The
client contributes only the hidden tab, which is presentation; the enforcement is
entirely server-side and deliberately redundant. `supabase/tests/functional.sql`
asserts all three, including one assertion that drops to the `authenticated` role
for a statement — the suite otherwise runs as the superuser, and a superuser
bypasses RLS entirely, which is how an RLS hole survives a green suite.

There is still no PostGIS and no coordinate column. `docs/21` §3 explains why.

### Translation

A "See translation" line under any post, comment, message or meetup note. It never
translates on its own.

Translations are cached by **sha256 of the source text**, not by the row they came
from — so identical text is translated once for everyone, an edit retranslates
rather than showing stale words, and deleting a post invalidates nothing.

**No provider is configured, on purpose.** `callProvider()` in
`supabase/functions/translate` is a single boundary with Google and DeepL both
written. With no key set it answers `provider: 'none'`, the client leaves the
original showing, and the button does not appear. Turning it on is one environment
variable — `GOOGLE_TRANSLATE_API_KEY` or `DEEPL_API_KEY` — with no client release
and no migration.

---

## The newest commit

### Endorsements — a feature the score had been advertising without providing

The Talent Score has told athletes to "ask a coach to endorse you" since it
shipped, and it means it: endorsements are worth **up to 45 of the 100
credibility points**. There has never been a way for the coach to do it.
`getEndorsements` read them; nothing wrote them. Every endorsement in the product
came from the seed file.

Adding the write path exposed two things that had never mattered because nobody
could reach the table. **Both are worth a look before this merges:**

- **`endorser_role` was client-supplied.** The insert policy was
  `with check (endorser_id = auth.uid())`, which constrains who you claim to be
  and nothing else about the row — and that column is exactly what
  `compute_talent_score` reads to decide whether an endorsement is an expert one.
  The join on `is_verified` is what has been holding the line, and it holds it
  well; but it is one condition away from a self-declared credential feeding a
  score. The server writes the role from the profile now, and the column is not
  writable by a client at all.
- **No unique constraint.** The score counts rows, so five copies of "Fast" from
  one verified coach was fifteen points. One row per (athlete, endorser, skill)
  now, plus six skills per endorser. The migration folds existing duplicates
  first, keeping the oldest of each group.

Twelve new SQL assertions cover it, including one that drops to the
`authenticated` role to prove a client cannot insert directly — the mirror of the
RLS trap above, and for the same reason.

### Three layout defects that all reported as "the right margins are wrong"

None of them was in a margin.

1. **The create button's breath was on a full-width box.** It is positioned
   `left: 0, right: 0` and scales 1 → 1.03. Scaling a 414pt box by 3% makes it
   426pt, hanging six points past **both** edges. A phone shows nothing for it;
   the web build is a real document, so the page became wider than the viewport,
   the whole app could be dragged sideways, and a strip of bare page sat down the
   right of **every** screen. Every margin in the app looked wrong at once and the
   cause was nowhere near any of them. Now two views: one positions, one
   animates and is the width of the button.
2. **`Card padded={false}` + `ListItem`.** Each is right alone and wrong
   together — the card is unpadded so its dividers run edge to edge, which leaves
   each row paying for its own margin, and rows are flush because 24 of the 26 of
   them live in a Sheet that already insets. "Who looked at your profile" had the
   avatar flat against the border, clipped by the card's own corner radius.
3. **`roleLabel` had no case for `medical_partner`**, so one showed as "Member".

And two console warnings that could not be fixed where they appeared to come
from. `expo-notifications` subscribes to push token changes **at module scope**,
so it warns the instant the module is evaluated — every `Platform.OS === 'web'`
guard in the hook was already too late. It now goes through `lib/push.ts`, which
has a `push.web.ts` twin Metro resolves first, taking the notifications module
and its abort-controller polyfill out of the web bundle entirely: **3.7 MB →
3.5 MB**. The other was sixty-five `useNativeDriver: true` in a runtime with no
native animated module; that is `NATIVE_DRIVER` now, and nothing changes on a
phone. `tests/e2e/console.mjs` walks the app and fails on any warning the app
owns — it reports clean.

Both of the first two are now **measured, not reviewed**: `tests/e2e/look.mjs`
asserts the document is never wider than the viewport on any screen and names
the widest offender when it is, and a new `tests/e2e/cards.mjs` measures every
card-like surface in the built app against everything drawn inside it.

### Demo data, one account per role

Endorsements are given by one account to another and follower lists are lists of
other people, so neither could be looked at against a four-role seed.
`supabase/seeds/demo.sql` now has thirteen accounts covering every role — scout,
federation and medical partner included, which sign-up does not offer — and a
follow graph thick enough that Followers and Following are lists. Every account
uses the password `AceAiX-Demo-2026`, and `start.sh` prints the lot.

The preview recorder now visits the follower screens. It did not before, which is
why the preview answered every follower list with "You're not following anyone
yet" — a gap in the recording that read exactly like a bug in the app.

### And two suites that check the backend actually delivers

`npm run test:backend`. The three suites that already existed answered narrower
questions than they looked like they did — in particular
`supabase/tests/functional.sql` runs **inside Postgres as the superuser**, over a
connection that has already skipped PostgREST, the anon key, the JWT, the
`authenticated` role and row-level security. A rule can be perfect and the
pipeline still broken.

- **`tests/e2e/pipelines.mjs`** signs in as the demo accounts over HTTP with the
  anon key, as the app does, writes as one of them and asks a *different* account
  whether it arrived. 29 steps: a coach's trial reaching an athlete's
  recommendations and her application reaching him back; a meetup found by a
  stranger, where asking does not take a spot and accepting does; a post reaching
  a follower's feed; an endorsement landing with the server-written role and
  moving the score; a message arriving; and a fourteen-year-old finding nothing.
- **`tests/e2e/contract.mjs`** checks the ~140 calls no journey walks. Every RPC
  name and argument, every selected and written column, against PostgREST's own
  schema cache — the class of break TypeScript cannot see, because
  `rpc('x', {...})` is a string and an untyped object.

Both pass. **CI gains a third job for them, and it is the first one that touches
a database** — before this, every migration in the repo was verified only by
somebody running the script on a laptop. `docs/23` covers what is still not
covered, including storage, edge functions and push.

---

## Two things this work exposed, worth knowing beyond this branch

**The local harness never exercised RLS.** Hosted Supabase grants `authenticated`
access to `public` tables by default; the local stand-in does not. So the read
policies on `challenges` — and every table added since — were never under test:
the table was simply unreadable and the suite passed for the wrong reason. The two
meetup tables grant `SELECT` explicitly so the policy is the thing being tested.
**The 0907 tables still have this gap** and closing it the same way is a small,
worthwhile follow-up.

**A new function in the `private` schema is callable unless you say otherwise.**
`0907/06` closed that schema with an `alter default privileges`, but that binds
only objects created by the role that ran it, and PostgreSQL still grants EXECUTE
to PUBLIC on every new function — which `anon` inherits. Three functions added here
were callable by any signed-in account until the whole-schema invariant test caught
them, one of them `prune_translations`, which deletes rows. Revoke explicitly in
the same migration; do not rely on the default.

---

## Running it

No credentials needed:

```bash
./tools/local-supabase/start.sh          # Postgres + PostgREST + auth/storage, no Docker
cd mobile && npm install && npx expo start
```

Applies all 43 migrations from scratch and seeds thirteen demo accounts plus two
meetups. It prints the two values for `mobile/.env` when it finishes, and the
sign-in for every role.

To just look at it: `cd mobile && npm run preview` bakes the whole app plus a
recording of every API call into one HTML file that opens anywhere.

**All green on `9d861df`:**

```bash
cd mobile && npm run typecheck && npm run test:unit && npm run lint
cd web    && npm run typecheck
./supabase/tests/run-all.sh              # with the harness up
cd mobile && node tests/e2e/look.mjs     # geometry + horizontal overflow
cd mobile && node tests/e2e/cards.mjs    # nothing touching a card edge
cd mobile && node tests/e2e/console.mjs  # no warnings the app is responsible for
cd mobile && npm run test:backend        # SQL rules, client↔db contract, write pipelines
```

1,484 mobile unit tests. All 43 migrations from scratch. 29 end-to-end write
pipelines. The three jobs in `.github/workflows/ci.yml` pass — **the third one is
new**, and until it existed nothing in CI touched a database at all.

---

## Still outstanding before either store will take this

`docs/15-known-gaps.md` §1 — store credentials, the review phone number,
moderation staffing, the NCMEC decision, the email-confirmation decision, and
`consent_ip` / `consent_user_agent`. Decisions, not code.

One more, new with this branch: meetups put adults in a physical place together,
which is a different risk surface from anything the app did before. Reporting and
blocking already apply (a blocked person's meetups are filtered out of search),
but whether that is sufficient for the stores — and for you — is a question worth
asking before launch rather than after.

Start at `docs/README.md`; `docs/21` covers meetups and translation, `docs/22`
covers endorsements and the three edges.
